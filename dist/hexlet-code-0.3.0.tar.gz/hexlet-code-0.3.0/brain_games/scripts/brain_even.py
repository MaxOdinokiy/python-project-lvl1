#!/usr/bin/env python3
from brain_games.cli import greet_user
from brain_games.games.is_even import play


def main():
    play()


if __name__ == '__main__':
    main()
